from prettytable import PrettyTable

tblBrg = PrettyTable()

print("-------------------------------------------------------------------")
print("              Thank you for using our program (eBPM)")
print("-------------------------------------------------------------------")

enter = input("Tekan enter untuk melanjutkan...\n")

print("""List Contributors :
Haekal Sastradilaga : Lead
Fariz Darmawan : Member
Rifkhy Eka : Member
Fauzan : Member
Nadif : Member """)

#Kodingan diatas hanya untuk print list kontribusi anggota kelompok saya

""" Copyright to Haekal Sastradilaga"""
